# twitter_optimus_twint
Analyzing tweets with Twint, Optimus and Apache Spark.
